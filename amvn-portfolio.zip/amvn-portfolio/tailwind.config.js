/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./index.html",
    "./src/**/*.{js,jsx}"
  ],
  theme: {
    extend: {
      colors: {
        amvnRed: {
          400: '#ef4444',
          500: '#dc2626',
          600: '#b91c1c'
        }
      },
      keyframes: {
        letterPop: {
          '0%': { opacity: 0, transform: 'scale(.5) translateY(20px)' },
          '100%': { opacity: 1, transform: 'scale(1) translateY(0)' }
        },
        progressGrow: {
          '0%': { width: '0%' },
          '100%': { width: '100%' }
        },
        gradientShift: {
          '0%,100%': { 'background-position': '0% 50%' },
          '50%': { 'background-position': '100% 50%' }
        }
      },
      animation: {
        letterPop: 'letterPop .9s cubic-bezier(.2,.9,.2,1) both',
        progressGrow: 'progressGrow 1s linear both',
        gradientShift: 'gradientShift 3s ease infinite'
      }
    }
  },
  plugins: []
}
