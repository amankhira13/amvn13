# AMVN — Billion-Dollar Portfolio (local & deploy)

This is a ready-to-run React + Tailwind project for Aman Khira (AMVN).  
**It includes your uploaded photo** at `public/photo.jpg`.

## Quick local run (you can see it live locally)
1. Install deps:
   ```bash
   npm install
   ```
2. Run dev server:
   ```bash
   npm run dev
   ```
3. Open the URL printed by Vite (usually http://localhost:5173) — the site will run live on your machine.

## Important: Telegram bot token (security)
- **Do NOT put your bot token in frontend code.**
- Set these environment variables for the server-side function:
  - `TELEGRAM_BOT_TOKEN` (your new token, do NOT paste it publicly)
  - `TELEGRAM_CHAT_ID` (your numeric chat id)

If deploying to Vercel, add them in Project → Settings → Environment Variables.

## Deploy quickly (Vercel recommended)
1. Push this repo to GitHub.
2. Import project into Vercel.
3. Add environment variables in Vercel.
4. Deploy — Vercel will serve the serverless function at `/api/sendTelegramMessage`.

## Files of note
- `src/` — React app
- `public/photo.jpg` — your uploaded image (used in Photo section)
- `api/sendTelegramMessage.js` — serverless function (reads token from env)

## Security reminder
You previously exposed a Telegram bot token publicly. **Revoke it immediately** via @BotFather and generate a new token. Use the new token only in your server environment variables.

Enjoy — run `npm run dev` and you’ll see the site live on your machine.
