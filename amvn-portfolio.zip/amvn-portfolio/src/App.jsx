import React from 'react'
import Navbar from './components/Navbar'
import Intro from './components/Intro'
import ParticleCanvas from './components/ParticleCanvas'
import Hero from './components/Hero'
import PhotoSection from './components/PhotoSection'
import InfoCards from './components/InfoCards'
import Skills from './components/Skills'
import Philosophy from './components/Philosophy'
import Stats from './components/Stats'
import ContactForm from './components/ContactForm'

export default function App(){
  return (
    <div className="min-h-screen relative overflow-x-hidden">
      <ParticleCanvas />
      <Navbar />
      <Intro />
      <main className="max-w-[1600px] mx-auto px-6">
        <section className="pt-8">
          <Hero />
        </section>

        <section className="pt-16 grid lg:grid-cols-2 gap-12 items-start">
          <PhotoSection />
          <div className="space-y-8">
            <InfoCards />
            <Skills />
            <Philosophy />
            <Stats />
          </div>
        </section>

        <section className="pt-20">
          <ContactForm />
        </section>

        <footer className="mt-20 pb-12 text-center text-gray-500">© {new Date().getFullYear()} AMVN — Built with ❤️</footer>
      </main>
    </div>
  )
}
