import React from 'react'

export default function InfoCards(){
  return (
    <div className="grid grid-cols-2 gap-6">
      <div className="glass p-8">
        <div className="text-sm text-gray-400 font-bold">Role</div>
        <div className="text-2xl font-black mt-2">Social Media Expert</div>
      </div>
      <div className="glass p-8">
        <div className="text-sm text-gray-400 font-bold">Specialty</div>
        <div className="text-2xl font-black mt-2">AI-Powered Dev</div>
      </div>
      <div className="glass p-8">
        <div className="text-sm text-gray-400 font-bold">Stack</div>
        <div className="text-2xl font-black mt-2">React · Node · Telegram API</div>
      </div>
      <div className="glass p-8">
        <div className="text-sm text-gray-400 font-bold">Availability</div>
        <div className="text-2xl font-black mt-2">24/7</div>
      </div>
    </div>
  )
}
