import React from 'react'

export default function Navbar(){
  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-black/80 backdrop-blur-2xl border-b border-white/5 px-6 py-4 flex justify-between items-center">
      <div className="text-2xl font-black">
        <span>AMV</span><span className="text-amvnRed-400">N</span>
      </div>
      <div className="flex items-center gap-8">
        <a href="#home" className="text-sm font-bold uppercase tracking-wide text-gray-400 hover:text-white">Home</a>
        <a href="#contact" className="text-sm font-bold uppercase tracking-wide text-gray-400 hover:text-white">Contact</a>
      </div>
    </nav>
  )
}
