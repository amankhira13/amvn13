import React from 'react'

export default function Stats(){
  const stats = [
    {v:'24/7', l:'Available'},
    {v:'100%', l:'Dedication'},
    {v:'∞', l:'Possibilities'}
  ]
  return (
    <div className="grid md:grid-cols-3 gap-6">
      {stats.map((s,i)=>(
        <div key={i} className="glass p-8 text-center">
          <div className="text-5xl font-black text-amvnRed-400">{s.v}</div>
          <div className="text-sm uppercase tracking-wide text-gray-400 mt-2">{s.l}</div>
        </div>
      ))}
    </div>
  )
}
