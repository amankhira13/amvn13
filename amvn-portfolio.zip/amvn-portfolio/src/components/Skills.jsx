import React from 'react'

export default function Skills(){
  const skills = [
    {title:'Social Media', desc:'Strategy & Growth'},
    {title:'Full-Stack Dev', desc:'React, Node, APIs'},
    {title:'AI Integration', desc:'Automation & Tools'},
    {title:'Automation', desc:'Workflows & Bots'},
  ]
  return (
    <div>
      <h3 className="text-2xl font-bold flex items-center gap-2">Expertise <span className="text-amvnRed-400">✦</span></h3>
      <div className="grid grid-cols-2 gap-4 mt-4">
        {skills.map((s,i)=>(
          <div key={i} className="p-4 bg-white/5 border border-white/10 rounded-lg flex items-center gap-4 hover:scale-105 transition">
            <div className="w-10 h-10 rounded-md bg-amvnRed-500/20 flex items-center justify-center">★</div>
            <div>
              <div className="font-semibold">{s.title}</div>
              <div className="text-sm text-gray-400">{s.desc}</div>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
