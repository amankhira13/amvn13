import React, { useState } from 'react'

export default function ContactForm(){
  const [form, setForm] = useState({ name:'', email:'', whatsapp:'', telegram:'', message:'' })
  const [loading, setLoading] = useState(false)
  const [success, setSuccess] = useState(false)

  function update(e){ setForm({...form,[e.target.name]: e.target.value}) }

  async function handleSubmit(e){
    e.preventDefault()
    setLoading(true)
    try {
      const res = await fetch('/api/sendTelegramMessage', {
        method:'POST',
        headers:{ 'Content-Type':'application/json' },
        body: JSON.stringify({ ...form })
      })
      const json = await res.json()
      if(res.ok) setSuccess(true)
      else alert(json?.error || 'Error sending')
    } catch(err){ alert('Network error') }
    finally{ setLoading(false) }
  }

  if(success){
    return (
      <div className="py-24 text-center">
        <div className="inline-block p-12 bg-green-800/30 border border-green-500 rounded-full">
          <svg width="80" height="80" viewBox="0 0 24 24" fill="none"><path d="M20 6L9 17l-5-5" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/></svg>
        </div>
        <h2 className="text-5xl font-black mt-8">Message Sent!</h2>
        <p className="text-2xl text-gray-400 mt-4">I’ll get back to you soon 🚀</p>
      </div>
    )
  }

  return (
    <div id="contact" className="grid lg:grid-cols-5 gap-8">
      <div className="lg:col-span-2">
        <h3 className="text-[64px] font-black leading-none">Let’s <span className="bg-clip-text text-transparent bg-gradient-to-r from-amvnRed-500 to-amvnRed-600">Connect</span></h3>
        <p className="text-xl text-gray-400 mt-4">Drop me a message. I’ll respond within 24 hours.</p>

        <div className="mt-8 glass p-6">
          <div className="text-sm text-gray-400 font-bold">Email</div>
          <div className="text-lg font-semibold">contact@amvn.in</div>
          <div className="text-sm text-gray-400 mt-2">Direct line to me</div>
        </div>
      </div>

      <div className="lg:col-span-3 glass p-8">
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-black uppercase text-gray-300">NAME</label>
            <input name="name" required value={form.name} onChange={update}
              className="w-full p-4 mt-2 rounded-xl bg-white/5 border border-white/10 focus:border-amvnRed-500" placeholder="Your name" />
          </div>

          <div>
            <label className="block text-sm font-black uppercase text-gray-300">EMAIL</label>
            <input name="email" type="email" required value={form.email} onChange={update}
              className="w-full p-4 mt-2 rounded-xl bg-white/5 border border-white/10 focus:border-amvnRed-500" placeholder="you@example.com" />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-black uppercase text-gray-300">WhatsApp</label>
              <input name="whatsapp" value={form.whatsapp} onChange={update}
                className="w-full p-4 mt-2 rounded-xl bg-white/5 border border-white/10" placeholder="+91xxxxxxxxxx" />
            </div>
            <div>
              <label className="block text-sm font-black uppercase text-gray-300">Telegram</label>
              <input name="telegram" value={form.telegram} onChange={update}
                className="w-full p-4 mt-2 rounded-xl bg-white/5 border border-white/10" placeholder="@username" />
            </div>
          </div>

          <div>
            <label className="block text-sm font-black uppercase text-gray-300">Message</label>
            <textarea name="message" rows="6" required value={form.message} onChange={update}
              className="w-full p-4 mt-2 rounded-xl bg-white/5 border border-white/10 resize-none" />
          </div>

          <div>
            <div className="text-sm text-amvnRed-400">* WhatsApp or Telegram required</div>
            <button type="submit" disabled={loading}
              className="mt-4 w-full p-6 bg-gradient-to-br from-amvnRed-500 to-amvnRed-600 rounded-xl font-black text-xl border-4 border-[rgba(239,68,68,0.25)] shadow-2xl">
              {loading ? 'Sending…' : 'Send Message'}
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}
