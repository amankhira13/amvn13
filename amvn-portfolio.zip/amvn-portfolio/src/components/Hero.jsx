import React from 'react'

export default function Hero(){
  return (
    <section id="home" className="pt-28 pb-12">
      <div className="flex flex-col lg:flex-row items-start gap-8">
        <div className="lg:w-1/2">
          <div className="inline-block py-2 px-4 bg-gradient-to-r from-amvnRed-600/20 to-amvnRed-500/20 rounded-full border border-amvnRed-500/20">
            <span className="text-sm font-bold text-white">ONLINE &amp; READY</span>
          </div>

          <h1 className="mt-6 hero-amvn text-[140px] md:text-[192px] leading-none">AMVN</h1>
          <h2 className="text-[72px] font-black text-transparent bg-clip-text bg-gradient-to-r from-amvnRed-500 via-amvnRed-400 to-amvnRed-500">Aman Khira</h2>
          <p className="lead mt-4">AI-Powered Full-Stack Developer · Social Media Expert</p>
        </div>

        <div className="lg:w-1/2 flex items-center justify-end">
          <div className="max-w-[420px] text-right">
            <p className="text-gray-400">Premium portfolio experience — animations, particles, glassmorphism, and a contact flow that reaches me instantly.</p>
          </div>
        </div>
      </div>
    </section>
  )
}
