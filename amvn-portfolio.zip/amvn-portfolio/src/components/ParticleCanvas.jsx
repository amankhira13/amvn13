import React, { useRef, useEffect } from 'react'

export default function ParticleCanvas(){
  const ref = useRef(null)

  useEffect(()=>{
    const canvas = ref.current
    const ctx = canvas.getContext('2d')
    let w = canvas.width = innerWidth
    let h = canvas.height = innerHeight
    const particles = []
    const COUNT = 120
    let mouse = { x: w/2, y: h/2, active:false }

    function rand(min,max){ return Math.random()*(max-min)+min }

    for(let i=0;i<COUNT;i++){
      particles.push({
        x: rand(0,w),
        y: rand(0,h),
        vx: rand(-0.4,0.8),
        vy: rand(-0.4,0.8),
        r: Math.round(rand(1,3)),
        o: rand(0.25,0.5)
      })
    }

    function draw(){
      ctx.clearRect(0,0,w,h)
      // orbs (blurred large)
      ctx.save()
      ctx.globalAlpha = 0.12
      ctx.fillStyle = '#ef4444'
      ctx.filter = 'blur(150px)'
      ctx.beginPath()
      ctx.ellipse(w*0.15, h*0.2, 340, 340, 0, 0, Math.PI*2)
      ctx.fill()
      ctx.beginPath()
      ctx.ellipse(w*0.85, h*0.75, 380, 380, 0, 0, Math.PI*2)
      ctx.fill()
      ctx.restore()
      // particles
      for(let i=0;i<particles.length;i++){
        const p = particles[i]
        if(mouse.active){
          const dx = mouse.x - p.x
          const dy = mouse.y - p.y
          const dist = Math.hypot(dx,dy)
          if(dist < 200){
            p.vx += dx/dist*0.02
            p.vy += dy/dist*0.02
          }
        }
        p.x += p.vx
        p.y += p.vy
        if(p.x < 0) p.x = w
        if(p.x > w) p.x = 0
        if(p.y < 0) p.y = h
        if(p.y > h) p.y = 0

        ctx.fillStyle = `rgba(239,68,68,${p.o})`
        ctx.beginPath()
        ctx.arc(p.x,p.y,p.r,0,Math.PI*2)
        ctx.fill()
      }
      // connections
      for(let i=0;i<particles.length;i++){
        for(let j=i+1;j<particles.length;j++){
          const a = particles[i], b = particles[j]
          const dx = a.x - b.x
          const dy = a.y - b.y
          const d = Math.hypot(dx,dy)
          if(d < 140){
            ctx.strokeStyle = `rgba(239,68,68,${(1 - d/140)*0.35})`
            ctx.lineWidth = 1
            ctx.beginPath()
            ctx.moveTo(a.x,a.y)
            ctx.lineTo(b.x,b.y)
            ctx.stroke()
          }
        }
      }
      requestAnimationFrame(draw)
    }

    draw()

    function onResize(){ w = canvas.width = innerWidth; h = canvas.height = innerHeight }
    function onMove(e){ mouse = { x: e.clientX, y: e.clientY, active:true } }
    function onLeave(){ mouse.active=false }

    window.addEventListener('resize', onResize)
    window.addEventListener('mousemove', onMove)
    window.addEventListener('mouseleave', onLeave)

    return ()=> {
      window.removeEventListener('resize', onResize)
      window.removeEventListener('mousemove', onMove)
      window.removeEventListener('mouseleave', onLeave)
    }
  },[])

  return <canvas ref={ref} className="fixed inset-0 -z-10" />
}
