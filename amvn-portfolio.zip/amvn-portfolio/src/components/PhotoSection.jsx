import React from 'react'

export default function PhotoSection(){
  return (
    <div className="space-y-6">
      <div className="relative max-w-[680px]">
        <img src="/photo.jpg" alt="Aman Khira" className="w-full photo-frame rounded-[48px]" />
        <div className="absolute -top-6 -left-6 w-28 h-6 border-t-4 border-l-4 border-amvnRed-400 animate-pulse" />
        <div className="absolute -bottom-6 -right-6 w-28 h-6 border-b-4 border-r-4 border-amvnRed-400 animate-pulse" />
        <div className="absolute -top-8 -right-8 px-3 py-2 rounded-xl bg-gradient-to-br from-amvnRed-500 to-amvnRed-600 border-2 border-[rgba(220,38,38,0.3)] transform rotate-3">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-white animate-pulse" />
            <span className="text-sm font-bold">AVAILABLE</span>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-6">
        {[
          {label:'Age', value:'21'},
          {label:'Height', value:"5'6\""},
          {label:'Complexion', value:'Fair'},
          {label:'Location', value:'Jamnagar'}
        ].map((c,i)=>(
          <div key={i} className="glass p-6 transform transition-all duration-500 hover:scale-105 hover:-rotate-2">
            <div className="text-sm uppercase tracking-wide text-gray-400 font-bold">{c.label}</div>
            <div className="text-4xl font-black mt-3 text-white">{c.value}</div>
          </div>
        ))}
      </div>
    </div>
  )
}
