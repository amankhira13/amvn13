import React, { useEffect, useState } from 'react'

export default function Intro(){
  const [show, setShow] = useState(true)
  useEffect(()=>{
    const t = setTimeout(()=> setShow(false), 3500)
    return ()=> clearTimeout(t)
  },[])
  if(!show) return null
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black">
      <div className="text-center">
        <div className="text-[110px] md:text-[140px] font-black leading-none">
          {['A','M','V','N'].map((ch, i)=> (
            <span
              key={i}
              className={`intro-letter ${ch==='A' || ch==='V' ? 'a' : 'm'}`}
              style={{ animation: `letterPop .9s ${0.5 + i*0.15}s cubic-bezier(.2,.9,.2,1) both` }}
            >{ch}</span>
          ))}
        </div>

        <div className="mt-6 text-sm text-gray-400">Loading Experience</div>
        <div className="mt-4 w-72 mx-auto progress-track" aria-hidden>
          <div className="progress-bar" style={{ animation: 'progressGrow 1s linear 1.2s forwards' }} />
        </div>
      </div>
    </div>
  )
}
