import React from 'react'

export default function Philosophy(){
  const lines = [
    {text:'I hate sleeping but my lazy ass still passes out at 4 AM', cls:'italic text-gray-500'},
    {text:"Haven't achieved shit yet. Still here.", cls:'text-gray-400'},
    {text:"Future's on God's to-do list.", cls:'text-gray-400'},
    {text:'Whatever happens, happens.', cls:'text-gray-400'},
    {text:'Fuck stress.', cls:'text-amvnRed-400 font-black text-xl'},
    {text:"Keep working, results will come or they won't – either way I'm chilling.", cls:'text-white font-bold'}
  ]
  return (
    <div className="glass p-8">
      {lines.map((l,i)=>(
        <div key={i} className={`mb-2 ${l.cls}`}>{l.text}</div>
      ))}
    </div>
  )
}
